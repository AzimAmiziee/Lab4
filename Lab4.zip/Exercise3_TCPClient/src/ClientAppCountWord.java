
public class ClientAppCountWord 
{
	public static void main(String[] args) 
	{
		//display GUI
		ClientFrame client = new ClientFrame();
		client.setVisible(true);
	}
}
